package com.example.tugas4;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {
    private TextView tvName, tvYear, tvMember, tvAbout;
    private ImageView imgGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        //koneksi antara java dengan xml
        tvName = findViewById(R.id.tvName);
        tvYear = findViewById(R.id.tvYear);
        tvMember = findViewById(R.id.tvMember);
        tvAbout = findViewById(R.id.tvAbout);
        imgGroup = findViewById(R.id.imgGroup);


        tvName.setText(getIntent().getStringExtra("name"));
        tvYear.setText(getIntent().getStringExtra("year"));
        tvMember.setText(getIntent().getStringExtra("member"));
        tvAbout.setText(getIntent().getStringExtra("about"));
        Glide.with(getApplicationContext())
                .load(getIntent().getStringExtra("image"))
                .into(imgGroup);


    }
}