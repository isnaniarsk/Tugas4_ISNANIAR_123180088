package com.example.tugas4;

import java.util.ArrayList;

public class DataGroup {

    private static String[] name = new String[]{
            "ATEEZ",
            "BTOB",
            "IKON",
            "SF9",
            "Stray Kids",
            "The Boyz"
    };

    private static String[] year = new String[]{
            "2018",
            "2012",
            "2015",
            "2016",
            "2018",
            "2017"
    };

    private static String[] member = new String[]{
            "Hongjoong, Seonghwa, Yunho, Yeosang, Choi San, Mingi, Wooyoung, Jongho",
            "Eunkwang, Minhyuk, Changsub, Peniel",
            "Jinhwan, Yunhyeong, Bobby, Donghyuk, Junhoe, Chanwoo",
            "Youngbin, Inseong, Jaeyoon, Dawon, Rowoon, Zuho, Taeyang, Hwiyoung, Chani",
            "Bang Chan, Lee Know, Changbin, Hyunjin, Han, Felix, Seungmin, I.N",
            "Sangyeon, Jacob, Younghoon, Hyunjae, Kevin, New, Q, Ju Haknyeon, Sunwoo, Eric"
    };

    private static String[] about = new String[]{
            "ATEEZ is a South Korean boy group formed by KQ Entertainment. They debuted on October 24, 2018 with the extended play (EP) Treasure EP.1: All to Zero.[4] As rookies, Ateez were recipients of the Next Generation Award at the 2019 Golden Disc Awards, as well as being named Worldwide Fans' Choice at both the 2019 and 2020 Mnet Asian Music Awards (MAMA). Ateez were also dubbed 4th Generation Leaders by the Korean Ministry of Culture, Sports, and Tourism, and are official global ambassadors for Korean culture and tourism, often referred to as Global Performance Idols by the Korean media.",
            "BTOB is a South Korean boy band formed in 2012 by Cube Entertainment. Originally a seven-member group, Jung Il-hoon departed from the group in December 2020. BtoB debuted on March 21, 2012, performing Insane (비밀) and Imagine on M Countdown. The group's debut EP, Born to Beat was released on April 3, 2012. They released their first full-length album, Complete, in June 2015. In November 2014, they made their Japanese debut with Wow under the Japanese agency Kiss Entertainment.",
            "iKON is a South Korean boy band formed in 2015 by YG Entertainment. First introduced in the reality survival show WIN: Who is Next as Team B, the group went on to appear in the 2014 reality survival show Mix & Match, which determined the final membership lineup of iKon. Originally a seven-piece band, B.I, departed from the group in June 2019.",
            "SF9 is a South Korean boy group formed by FNC Entertainment and the company's first dance boy group.the group debuted on October 5, 2016 with the release of their first single album, Feeling Sensation. SF9's first Korean studio album, First Collection, was released on January 7, 2020 with the lead single Good Guy. They broke multiple sales, charts and music video records during this comeback, making this comeback their most successful yet. This included selling over 100,000 copies of their album, all songs charting on the Melon Realtime Chart, and their music video reaching over 40 million views.",
            "Stray Kids is a South Korean boy band formed by JYP Entertainment through the 2017 reality show of the same name. Originally a nine-piece group, member Woojin left Stray Kids due to undisclosed personal reasons in October 2019. The group released their extended play Mixtape in January 2018 and officially debuted on March 25 with I Am Not.",
            "The Boyz is a South Korean boy group formed by Cre.ker Entertainment. The group debuted on December 6, 2017. Originally a 12-piece group, former member Hwall officially left the group in October 2019 due to health reasons."
    };

    private static String[] image = new String[]{
            "https://koreanindo.net/wp-content/uploads/2021/03/ATEEZ4-1473x2048.jpg",
            "https://koreanindo.net/wp-content/uploads/2021/03/BTOB-1473x2048.jpg",
            "https://koreanindo.net/wp-content/uploads/2021/03/iKON3-1473x2048.jpg",
            "https://koreanindo.net/wp-content/uploads/2021/03/SF9-1473x2048.jpg",
            "https://koreanindo.net/wp-content/uploads/2021/03/Stray-Kids2-1473x2048.jpg",
            "https://koreanindo.net/wp-content/uploads/2021/03/THE-BOYZ-1473x2048.jpg"

    };



    static ArrayList<com.example.tugas4.Group> getDataGroup() {
        ArrayList<com.example.tugas4.Group> list = new ArrayList<>();
        for (int position = 0; position < name.length; position++) {
            com.example.tugas4.Group group = new com.example.tugas4.Group();
            group.setName(name[position]);
            group.setYear(year[position]);
            group.setMember(member[position]);
            group.setAbout(about[position]);
            group.setImage(image[position]);
            list.add(group);
        }
        return list;
    }
}
